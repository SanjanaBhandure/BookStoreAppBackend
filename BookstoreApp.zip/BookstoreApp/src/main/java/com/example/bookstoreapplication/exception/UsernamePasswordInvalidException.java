package com.example.bookstoreapplication.exception;

public class UsernamePasswordInvalidException extends Exception {

    public UsernamePasswordInvalidException(String message) {
        super(message);
    }
}
